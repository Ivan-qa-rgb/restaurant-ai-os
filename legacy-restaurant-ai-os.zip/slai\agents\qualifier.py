﻿import json
from slai.agents.base_agent import BaseAgent
from slai.agents.guest_state import GuestState
from slai.agents.date_utils import normalize_date


class QualifierAgent(BaseAgent):
    name = "qualifier"
    system_prompt = (
        "Ты помощник администратора ресторана. "
        "Извлеки из сообщения гостя данные брони. "
        "Верни только JSON без пояснений. "
        "Формат: {\"party_size\": int, \"date\": \"\", \"time\": \"\", \"occasion\": \"\", \"missing_fields\": []}. "
        "Если данных нет, используй null или пустую строку."
    )

    def extract(self, message):
        prompt = f"Сообщение гостя: {message}"
        raw = self.run(prompt)

        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            data = {}

        state = GuestState()
        state.party_size = data.get("party_size") or 0
        state.date = normalize_date(data.get("date") or "")
        state.time = data.get("time") or ""
        state.occasion = data.get("occasion") or ""
        state.missing_fields = data.get("missing_fields") or []

        return state
