﻿from slai.agents.qualifier import QualifierAgent
from slai.agents.date_utils import normalize_date
from slai.storage.reservations import ReservationService

agent = QualifierAgent()
service = ReservationService()

state = agent.extract("\u0425\u043e\u0447\u0443 \u0437\u0430\u0431\u0440\u043e\u043d\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u0441\u0442\u043e\u043b \u043d\u0430 4 \u0447\u0435\u043b\u043e\u0432\u0435\u043a \u0437\u0430\u0432\u0442\u0440\u0430 \u0432 19:00")
date = normalize_date(state.date)

reservation = service.create_reservation(
    guest_id="guest_1",
    date=date,
    time=state.time,
    party_size=state.party_size,
)

print(state.to_dict())
print(reservation)
