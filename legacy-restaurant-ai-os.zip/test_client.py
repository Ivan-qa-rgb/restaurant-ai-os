﻿from slai.llm.ollama_client import OllamaClient

client = OllamaClient()
print(client.generate("\u041f\u0440\u0438\u0432\u0435\u0442"))
