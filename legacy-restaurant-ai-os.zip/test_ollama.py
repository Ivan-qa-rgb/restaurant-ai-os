﻿import requests

url = "http://localhost:11434/api/generate"

payload = {
    "model": "qwen3:4b",
    "prompt": "\u041f\u0440\u0438\u0432\u0435\u0442",
    "stream": False,
}

response = requests.post(url, json=payload, timeout=120)
response.raise_for_status()

data = response.json()
print(data["response"])
