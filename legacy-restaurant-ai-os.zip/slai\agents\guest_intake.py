﻿from slai.agents.base_agent import BaseAgent


class GuestIntakeAgent(BaseAgent):
    name = "guest_intake"
    system_prompt = (
        "Ты вежливый администратор ресторана вологодской кухни. "
        "Помоги гостю выбрать дату, время и количество гостей. "
        "Отвечай кратко, по-русски и только на основе известной информации."
    )
